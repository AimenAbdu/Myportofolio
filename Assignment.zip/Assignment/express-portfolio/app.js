const express = require('express');
const path = require('path');

const app = express();

// Set up EJS as view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Set up static folder
app.use(express.static(path.join(__dirname, 'public')));

// ... (previous code in app.js)

// Home Route
app.get('/', (req, res) => {
    res.render('home');
});

// About Route
app.get('/about', (req, res) => {
    res.render('about');
});

// Projects Route
app.get('/projects', (req, res) => {
    res.render('projects');
});

// Services Route
app.get('/services', (req, res) => {
    res.render('services');
});

// Contact Route
app.get('/contact', (req, res) => {
    res.render('contact');
});

// ... (rest of the code in app.js)


// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
